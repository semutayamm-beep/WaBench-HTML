package com.chyps.htmlbench;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

    private WebView wv;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        wv = new WebView(this);
        wv.getSettings().setJavaScriptEnabled(true);
        wv.getSettings().setDomStorageEnabled(true);
        wv.getSettings().setAllowFileAccess(true);
        wv.getSettings().setAllowFileAccessFromFileURLs(true);
        wv.getSettings().setAllowUniversalAccessFromFileURLs(true);
        wv.setWebViewClient(new WebViewClient());
        wv.addJavascriptInterface(new Bridge(), "Chyps");
        setContentView(wv);
        wv.loadUrl("file:///android_asset/index.html");
    }

    public class Bridge {

        @JavascriptInterface
        public String direct(String number, String payload) {
            try {
                String url = "https://wa.me/" + number + "?text=" + Uri.encode(payload);
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                return "ok";
            } catch (ActivityNotFoundException e) {
                return "noapp";
            } catch (Exception e) {
                return "err:" + e.getMessage();
            }
        }

        @JavascriptInterface
        public String send(String payload) {
            Intent base = new Intent(Intent.ACTION_SEND);
            base.setType("text/plain");
            base.putExtra(Intent.EXTRA_TEXT, payload);
            base.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            if (tryPkg(base, "com.whatsapp")) return "ok";
            if (tryPkg(base, "com.whatsapp.w4b")) return "ok";
            return "noapp";
        }

        private boolean tryPkg(Intent base, String pkg) {
            Intent i = new Intent(base);
            i.setPackage(pkg);
            try { startActivity(i); return true; }
            catch (Exception e) { return false; }
        }

        @JavascriptInterface
        public String flood(String number, String payload, int count) {
            for (int k = 0; k < count; k++) {
                direct(number, payload);
                try { Thread.sleep(120); } catch (InterruptedException ignored) {}
            }
            return "ok";
        }
    }
}
